package filesprocessing;

/**
 * Created by Snir on 5/25/2016.
 */
public class Type2Exception extends Exception {

}
