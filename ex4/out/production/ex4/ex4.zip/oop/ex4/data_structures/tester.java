package oop.ex4.data_structures;


import java.util.Iterator;
import java.util.Objects;

/**
 * Created by snirsh on 5/8/16.
 */
public class tester {
    public static void main(String[] args){
        AvlTree tree = new AvlTree();
        System.out.print(tree.add(5));
        System.out.print(tree.add(7));
        System.out.print(tree.add(6));
        System.out.print(tree.contains(5));
        System.out.print(tree.contains(6));
        System.out.print(tree.contains(7));

    }
}
